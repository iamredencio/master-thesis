### NBA Win Probabilities

This directory contains the data behind the story:

[Every NBA Team’s Chance Of Winning In Every Minute Across Every Game](https://fivethirtyeight.com/features/every-nba-teams-chance-of-winning-in-every-minute-across-every-game/)

There is one data file:

 * `nba.tsv` - The 2014-15 NBA season win probabilities for each team over the course of a game, as of February 18, 2015

